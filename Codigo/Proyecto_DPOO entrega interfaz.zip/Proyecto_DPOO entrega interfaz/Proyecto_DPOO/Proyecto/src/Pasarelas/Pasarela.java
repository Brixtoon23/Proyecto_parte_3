package Pasarelas;

public interface Pasarela
{
    boolean procesarPago();
}