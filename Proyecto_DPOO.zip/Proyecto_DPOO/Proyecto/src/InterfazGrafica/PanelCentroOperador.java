package InterfazGrafica;

import javax.swing.JPanel;

import java.awt.Dimension;
import java.awt.GridLayout;

public class PanelCentroOperador extends JPanel
{
    public PanelCentroOperador()
    {
        setLayout(new GridLayout(5,1,20,20));
        setPreferredSize(new Dimension(200,200));
    }
    


}
